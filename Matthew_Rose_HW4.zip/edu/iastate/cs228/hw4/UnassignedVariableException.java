package hw4;

@SuppressWarnings("serial")
public class UnassignedVariableException extends Exception
{
	public UnassignedVariableException()
	{
		super();
	}
	  
	public UnassignedVariableException(String msg)
	{
	    super(msg);
	}

}

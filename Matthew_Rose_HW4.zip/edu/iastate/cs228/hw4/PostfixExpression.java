package edu.iastate.cs228.hw4;

/**
 *  
 * @author Matthew Rose
 *
 */

/**
 * 
 * This class evaluates a postfix expression using one stack.    
 *
 */

import java.util.HashMap;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class PostfixExpression 
{
	private String postfixExpression; 	      // postfix expression to evaluate
	private String tempPostfix;				  // Temporary expression holder	
	private PureStack<Integer> operandStack;  // stack of operands

	private int leftOperand;                  // left operand for the current evaluation step             
	private int rightOperand;                 // right operand for the current evaluation step	
	
	private HashMap<Character, Integer> varTable; // hash table to store variables in the 
	  											  // infix expression and their values 

	/**
	 * Constructor stores the input postfix string and initializes the operand stack.
	 * @param st  input postfix string. 
	 * @param varTbl  hash table that stores variables from the postfix string and their values.
	 */
	public PostfixExpression (String st, HashMap<Character, Integer> varTbl) throws UnassignedVariableException 
	{
		varTable = varTbl;
		Scanner temp = new Scanner(st);
		int sum = 0;
		if(temp.next().equals("P")){
			st = temp.nextLine().trim();
			tempPostfix = st;
		} else tempPostfix = st;
		Scanner scanner = new Scanner(st);
		temp.close();
		while(scanner.hasNext()){
			if(scanner.hasNextInt()) {
				sum++;
				scanner.next();
			} else {
				String ch = scanner.next();
				switch(ch){
				case "+": 
					sum--;
					break;
				case "-":
					sum--;
					break;
				case "*":
					sum--;
					break;
				case "/":
					sum--;
					break;
				case "%":
					sum--;
					break;
				case "^":
					sum--;
					break;
				case "(":
					throw new IllegalArgumentException("Parentheses are not allowed in postfix expressions.");
				case ")":
					throw new IllegalArgumentException("Parentheses are not allowed in postfix expressions.");
				default:
					char check = ch.charAt(0);
					if(check >= 'a' && check <= 'z'){
						if(!varTable.containsKey(check)) throw new UnassignedVariableException("Variable " + check + " was not assigned a value");
						int var = varTable.get(check);
						String s = "" + var;
						tempPostfix = tempPostfix.replaceAll(ch, s);
						sum++;
					}
					else throw new IllegalArgumentException("Illegal operator");
					break;
				}
			}
		}
		scanner.close();
		if(sum != 1) throw new IllegalArgumentException("Postfix expression is lopsided");
		postfixExpression = st;
		operandStack = new ArrayBasedStack<Integer>();
	}
	

	// Default constructor 
	public PostfixExpression ()
	{
		postfixExpression = null; 
		varTable = null; 
	}
	

	/**
	 * Outputs the postfix expression according to the format in the project description.
	 * Generates an empty string if the postfix expression is invalid. Also in this case handle 
	 * the exception throw by evaluate() by printing out the corresponding error message. 
	 */
	public String toString()
	{ 
		String post = "";
		String c = "";
		Scanner scanner = new Scanner(postfixExpression);
		while(scanner.hasNext()){
			c = scanner.next().trim();
			if(c.equals("P"));
			else post += c + " ";
		}
		scanner.close();
		return post; 
	}
	

	/**
	 * Resets the postfix expression. 
	 * @param st
	 */
	public void resetPostfix (String st)
	{
		postfixExpression = st; 
	}


	/**
     * Scan the postfixExpression and carry out the following:  
     *    1. Whenever an integer is encountered, push it onto operandStack.
     *    2. Whenever an operator is encountered, invoke it on the two elements popped from  
     *       operandStack,  and push the result back onto the stack.  
     *    3. If a character that is not a digit, an operator, or a blank space is encountered, stop 
     *       the evaluation. 
     *       
     * @return value of the postfix expression 
     * @throws ExpressionFormatException with one of the messages below:  
     *           -- "Invalid character" if encountering a character that is not a digit, an operator
     *              or a whitespace (blank, tab); 
     *           --	"Too many operands" if operandStack is non-empty at the end of evaluation; 
     *           -- "Too many operators" if getOperands() throws NoSuchElementException; 
     *           -- "Divide by zero" if division or modulo is the current operation and rightOperand == 0;
     *           -- "0^0" if the current operation is "^" and leftOperand == 0 and rightOperand == 0;
     *           -- self-defined message if the error is not one of the above.
     *           
     *         UnassignedVariableException if the operand as a variable does not have a value stored
     *            in the hash table.  In this case, the exception is thrown with the message
     *            
     *           -- "Variable <name> was not assigned a value", where <name> is the name of the variable.  
     *           
     */
	public int evaluate() throws ExpressionFormatException, UnassignedVariableException 
    {
    	int res = 0;
    	char op = ' ';
    	Scanner scanner = new Scanner(tempPostfix);
    	while(scanner.hasNext()){
    		if(scanner.hasNextInt()){
    			operandStack.push(scanner.nextInt());    			
    		} else {
    			op = scanner.next().charAt(0);
    			if((op == '/' || op == '%') && rightOperand == 0) {
    				scanner.close();
    				throw new ExpressionFormatException("Divide by zero");
    			}
    			operandStack.push(compute(op));
    		}
    	}
    	res = operandStack.pop();
    	scanner.close();
    	if(!operandStack.isEmpty()) throw new ExpressionFormatException("Too many operands");
		return res;
    }
	

    /**
     * 
     * Pops the right and left operands from operandStack, and assign them to rightOperand 
     * and leftOperand, respectively. The stack must have at least two entries.  Otherwise, 
     * throws NoSuchElementException.  
     */
	private void getOperands() throws NoSuchElementException 
	{
		if(!operandStack.isEmpty()) rightOperand = operandStack.pop();
		else throw new NoSuchElementException("Stack is empty.");
		if(!operandStack.isEmpty()) leftOperand = operandStack.pop();
		else throw new NoSuchElementException("Stack is empty.");
	}


	/**
	 * Computes "leftOperand op rightOprand". 
	 * @param op operator that acts on leftOperand and rightOperand. 
	 * @return
	 */
	private int compute(char op)  throws ExpressionFormatException
	{
		int res = 0;
		try{
			getOperands();
		} catch (NoSuchElementException e) {
			throw new ExpressionFormatException("Too many operators");
		}
		switch(op){
		case '+': 
			res = leftOperand + rightOperand;
			break;
		case '-':
			res = leftOperand - rightOperand;
			break;
		case '*':
			res = leftOperand * rightOperand;
			break;
		case '/':
			if(leftOperand == 0 || rightOperand == 0) throw new ExpressionFormatException("Cannot divide by zero");
			res = leftOperand / rightOperand;
			break;
		case '%':
			res = leftOperand % rightOperand;
			break;
		case '^':
			if(leftOperand == 0 && rightOperand == 0) throw new ExpressionFormatException("0^0 (should return 1 as anything to the zeroth power is 1)");
			res = (int) Math.pow(leftOperand, rightOperand);
			break;
		default:
			throw new ExpressionFormatException("Invalid character");
		}
		return res; 
	}

}

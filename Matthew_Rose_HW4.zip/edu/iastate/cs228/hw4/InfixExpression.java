package edu.iastate.cs228.hw4;

/**
 *  
 * @author Matthew Rose
 *
 */

import java.util.HashMap;
import java.util.Scanner;

/**
 * 
 * This class represents an infix expression. It implements infix to postfix conversion using 
 * one stack, and evaluates the postfix equivalent of an infix expression.    
 *
 */

public class InfixExpression 
{
	private String infixExpression;   // the infix expression to convert
	private String tempInfix;		  // Temporary expression holder
	private String postfixExpression = ""; // the postfix equivalent of infixExpression
	private boolean postfixReady = false; 
	
	private ArrayBasedStack<Operator> operatorStack = new ArrayBasedStack<Operator>(); 	  // stack of operators 
	private HashMap<Character, Integer> varTable; // hash table storing variables in the 
												  // infix expression and their values 

	
	
	/**
	 * Constructor stores the input infix string, and initializes the operand stack and 
	 * the hash table.
	 * @param st  input infix string. 
	 * @param varTbl  hash table storing all variables in the infix expression and their values. 
	 * @throws UnassignedVariableException, ExpressionFormatException, IllegalArgumentException
	 */
	public InfixExpression (String st, HashMap<Character, Integer> varTbl) throws UnassignedVariableException, ExpressionFormatException, IllegalArgumentException
	{
		varTable = varTbl;
		Scanner temp = new Scanner(st);
		int sum = 0;
		if(temp.next().equals("I")){
			st = temp.nextLine().trim();
			tempInfix = st;
		} else tempInfix = st;
		Scanner scanner = new Scanner(st);
		temp.close();
		while(scanner.hasNext()){
			if(scanner.hasNextInt()) {
				sum++;
				if(scanner.nextInt() < 0) {
					scanner.close();
					throw new ExpressionFormatException("Negative operand not allowed");
				}
			}
			else{
				String ch = scanner.next();
				switch(ch){
				case "+": 
					sum--;
					break;
				case "-":
					sum--;
					break;
				case "*":
					sum--;
					break;
				case "/":
					sum--;
					break;
				case "%":
					sum--;
					break;
				case "^":
					sum--;
					break;
				case "(":
					break;
				case ")":
					break;
				case "=":
					break;
				default:
					char check = ch.charAt(0);
					if(check >= 'a' && check <= 'z'){
						if(!varTable.containsKey(check)) throw new UnassignedVariableException("Variable " + check + "was not assigned a value");
						int var = varTable.get(check);
						String s = "" + var;
						tempInfix = tempInfix.replaceAll(ch, s);
						sum++;
					}
					else throw new IllegalArgumentException("Invalid character");
					break;
				}
			}
		}
		scanner.close();
		if(sum != 1) throw new IllegalArgumentException("Infix expression is lopsided");
		infixExpression = st;
	}
	

	// Default constructor 
	public InfixExpression ()
	{
		infixExpression = null; 
		varTable = null;
	}
	

	/**
	 * Outputs the infix expression according to the format in the project description.
	 */
	public String toString()
	{
		String infix = "";
		String c = "";
		Scanner scanner = new Scanner(infixExpression);
		while(scanner.hasNext()){
			c = scanner.next().trim();
			if(c.equals("I"));
			else infix += c + " ";
		}
		scanner.close();
		return infix;  
	}
	
	
	/** 
	 * 
	 * @return the equivalent postfix expression 
	 * Returns a null string if a call to postfix() inside the body (when postfixReady 
	 * == false) throws an exception.
	 */
	public String postfixString() 
	{
		try{
			postfix();
		} catch (ExpressionFormatException e){
			System.out.println(e);
			return null;
		}
		return postfixExpression;
	}


	/**
	 * Resets the infix expression. 
	 * @param st
	 */
	public void resetInfix (String st)
	{
		infixExpression = st;
	}


	/**
	 * Converts infixExpression to an equivalent postfix string stored at postfixExpression.
	 * If postfixReady == false, the method scans the infixExpression, and does the following: 
	 * 
	 *     1. Skips a whitespace character.
	 *     2. Writes a scanned operand to postfixExpression.
	 *     3. If a scanned operator has a higher input precedence than the stack precedence of 
	 *        the operator on the top of operatorStack, push it onto the stack.   
	 *     4. Otherwise, first calls outputHigherOrEqual() before pushing the scanner operator 
	 *        onto the stack. No push if the scanned operator is ). 
     *     5. Keeps track of the cumulative rank of the infix expression. 
     *     
     *  During the conversion, catches errors in the infixExpression by throwing 
     *  ExpressionFormatException with one of the following messages:
     *  
     *      -- "Operator expected" if the cumulative rank goes above 1;
     *      -- "Operand expected" if the rank goes below 0; 
     *      -- "Missing '('" if scanning a �)� results in popping the stack empty with no '(';
     *      -- "Missing ')'" if a '(' is left unmatched on the stack at the end of the scan; 
     *      -- "Invalid character" if a scanned char is neither a digit nor an operator; 
     *      -- "Negative operand not allowed" if the input operand is negative
     *   
     *   If an error is not one of the above types, throw the exception with a message you define.
     *      
     *  Sets postfixReady to true.  
	 */
	public void postfix() throws ExpressionFormatException
	{
		if(!postfixReady){
			int sum = 0;
			Operator op = null;
			String opChar = "";
			Scanner scanner = new Scanner(tempInfix);
			while(scanner.hasNext()){
				if(scanner.hasNextInt()){
					int operand = scanner.nextInt();
					if(operand < 0){
						scanner.close();
						throw new ExpressionFormatException("Negative operand not allowed");
					} else {
						postfixExpression += operand + " ";
					}
					sum++;
				} else {
					opChar = scanner.next();
					op = new Operator(opChar.charAt(0));
					if(op.getOp() == '(') operatorStack.push(op);
					else {
						outputHigherOrEqual(op);
						if(op.getOp() != ')') sum--;
					}
				}
				if(sum > 1){
					scanner.close();
					throw new ExpressionFormatException("Operator expected");
				} else if (sum < 0){
					scanner.close();
					throw new ExpressionFormatException("Operand expected");
				}
			}
			while(!operatorStack.isEmpty()){
				if(operatorStack.peek().getOp() != '(')
					postfixExpression += Character.toString(operatorStack.pop().getOp()) + " ";
				else operatorStack.pop();
			}
			scanner.close();
			postfixReady = true;
		}
	}
	
	
	/**
	 * This function first calls postfix() to convert infixExpression into postfixExpression. Then 
	 * it creates a PostfixExpression object and calls its evaluate() method (which may throw  
	 * an exception).  It passes exceptions thrown by the evaluate() method of the 
	 * PostfixExpression object upward the chain. 
	 * 
	 * @return value of the infix expression 
	 * @throws ExpressionFormatException, UnassignedVariableException
	 */
	public int evaluate() throws ExpressionFormatException, UnassignedVariableException 
    {
		int eval = -1;
    	try{
    		String temp = "P " + postfixExpression;
    		PostfixExpression postfix = new PostfixExpression(temp, varTable);
    		eval = postfix.evaluate();
    		return eval;
    	} catch (ExpressionFormatException e){
    		System.out.println(e);
    	}
    	return eval;
    }


	/**
	 * Pops the operator stack and output as long as the operator on the top of the stack has a 
	 * stack precedence greater than or equal to the input precedence of the current operator op.  
	 * Writes the popped operators to the string postfixExpression. 
	 * 
	 * If op is a ')', and the top of the stack is a '(', also pops '(' from the stack but does 
	 * not write it to postfixExpression. 
	 * 
	 * @param op  Current operator
	 */
	private void outputHigherOrEqual(Operator op) throws ExpressionFormatException
	{
		if(op.operator == ')'){
			while(operatorStack.peek().getOp() != '('){
				postfixExpression += Character.toString(operatorStack.pop().getOp()) + " ";
				if(operatorStack.isEmpty()) throw new ExpressionFormatException("Missing '('");
			}
			operatorStack.pop();
		} else if(!operatorStack.isEmpty() && operatorStack.peek().compareTo(op) > -1){
			postfixExpression += Character.toString(operatorStack.pop().getOp()) + " ";
			operatorStack.push(op);
		} else {
			operatorStack.push(op);
		}
	}
}

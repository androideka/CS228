package hw4;

/**
 *  
 * @author Steve Kautz
 *
 */

/**
 * Expression thrown in PostfixExample for an invalid expression.
 */
@SuppressWarnings("serial")
public class ExpressionFormatException extends Exception
{
  public ExpressionFormatException()
  {
    super();
  }
  
  public ExpressionFormatException(String msg)
  {
    super(msg);
  }
}


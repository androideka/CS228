package edu.iastate.cs228.hw4;

/**
 *  
 * @author Matthew Rose
 *
 */

/**
 * 
 * This class evaluates input infix and postfix expressions. 
 *
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class InfixPostfix 
{

	/**
	 * Repeatedly evaluates input infix and postfix expressions.  See the project description
	 * for the input description. It constructs a HashMap object for each expression and passes it 
	 * to the created InfixExpression or PostfixExpression object. 
	 *  
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 * @throws UnassignedVariableException 
	 * @throws ExpressionFormatException 
	 **/
	public static void main(String[] args) throws NumberFormatException, IOException, ExpressionFormatException, UnassignedVariableException 
	{
		HashMap<Character, Integer> varTable = new HashMap<Character, Integer>();
		int operation = -1;
		int i = 1;
		String expression = "";
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Evaluation of Infix and Postfix Expressions\n");
		System.out.println("keys: 1 = (standard input)  2 = (file input)  3 = (exit)\n");
		System.out.println("(Enter “I” before an infix expression, “P” before a postfix expression, and a space in between each character”)\n\n\n");
		System.out.println("Which operation would you like to perform?");
		operation = Integer.parseInt(in.readLine());
		while(operation != 3){
			System.out.println("Trial " + i + ": " + operation + "\n");
			switch(operation){
			// Standard Input
			case 1:
				String op = "";
				System.out.println("Expression: ");
				expression = in.readLine();
				if(expression.length() < 3) throw new IllegalArgumentException("Must input a valid expression");
				varTable = findVars(expression);
				System.out.println("\n\n");
				Scanner scanner = new Scanner(expression);
				if(scanner.hasNext()) op = scanner.next();
				if(op.equals("P")){
					PostfixExpression post = new PostfixExpression(expression, varTable);
					if(!varTable.isEmpty()) System.out.println(varTable.toString() + "\n");
					System.out.println("Postfix form: " + post.toString() + "\n");
					System.out.println("Value: " + post.evaluate());
				} else if(op.equals("I")){
					InfixExpression infix = new InfixExpression(expression, varTable);
					if(!varTable.isEmpty()) System.out.println(varTable.toString() + "\n");
					System.out.println("Infix form: " + infix.toString() + "\n");
					System.out.println("Postfix form: " + infix.postfixString());
					System.out.println("Value: " + infix.evaluate());
				} else {
					System.out.println("You must enter a valid expression. Remember to type 'I' before an infix and 'P' before a postfix.");
				}
				scanner.close();
				varTable.clear();
				break;
			// File Input
			case 2:
				System.out.println("Input from a file\n");
				System.out.println("Enter file name: ");
				File file = new File(in.readLine());  // Specify file to be read
				Scanner fileIn = new Scanner(file);
				System.out.println("Infix (I) or Postfix (P)?");
				String op2 = in.readLine();
				int exprCount = 0;
				while(fileIn.hasNextLine()){
					if(exprCount >= 1) fileIn.nextLine();
					String expr = fileIn.nextLine();
					if(expr.length() < 3) throw new IllegalArgumentException("Read an invalid expression");
					ArrayList<String> list = findVarsNoInput(expr);
					if(!list.isEmpty()){
						for(int k = 0; k < list.size(); k++){
							fileIn.nextLine();
							String var = fileIn.next();
							fileIn.next();
							int val = fileIn.nextInt();
							varTable.put(var.charAt(0), val);
						}
					}
					if(op2.equals("P")){
						PostfixExpression postFile = new PostfixExpression(expr, varTable);
						if(!varTable.isEmpty()) System.out.println(varTable.toString() + "\n");
						System.out.println("Postfix form: " + postFile.toString() + "\n");
						System.out.println("Value: " + postFile.evaluate()); 
					} else if (op2.equals("I")){
						InfixExpression infixFile = new InfixExpression(expr, varTable);
						if(!varTable.isEmpty()) System.out.println(varTable.toString() + "\n");
						System.out.println("Infix form: " + infixFile.toString() + "\n");
						System.out.println("Postfix form: " + infixFile.postfixString());
						System.out.println("Value: " + infixFile.evaluate());
					} else {
						System.out.println("You must enter a valid operation, I or P");
					}
					exprCount++;
				}
				break;
			default:
				System.out.println("You must enter a valid operation number. \nType 1 to input directly, 2 to read from a file, and 3 to exit the program.");
				break;
			}
			i++;
			System.out.println("Which operation would you like to perform?");
			operation = Integer.parseInt(in.readLine());
		}
		System.out.println("Goodbye.");
	}
	
	// helper methods 
	
	
	// Finds variables in expression and adds to hash map (for standard input)
	private static HashMap<Character, Integer> findVars(String st) throws NumberFormatException, IOException{
		HashMap<Character, Integer> varTable = new HashMap<Character, Integer>(16);
		ArrayList<String> list = new ArrayList<String>();
		String var = "";
		int val = 0;
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		Scanner scanner = new Scanner(st);
		System.out.println("Variable values: \n");
		while(scanner.hasNext()){
			var = scanner.next();
			if(!list.contains(var)){
				list.add(var);
				switch(var){
				case "a":
					System.out.println("a: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('a', val);
					break;
				case "b":
					System.out.println("b: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('b', val);
					break;
				case "c":
					System.out.println("c: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('c', val);
					break;
				case "d":
					System.out.println("d: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('d', val);
					break;
				case "e":
					System.out.println("e: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('e', val);
					break;
				case "f":
					System.out.println("f: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('f', val);
					break;
				case "g":
					System.out.println("g: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('g', val);
					break;
				case "h":
					System.out.println("h: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('h', val);
					break;
				case "i":
					System.out.println("i: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('i', val);
					break;
				case "j":
					System.out.println("j: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('j', val);
					break;
				case "k":
					System.out.println("k: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('k', val);
					break;
				case "l":
					System.out.println("l: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('l', val);
					break;
				case "m":
					System.out.println("m: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('m', val);
					break;
				case "n":
					System.out.println("n: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('n', val);
					break;
				case "o":
					System.out.println("o: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('o', val);
					break;
				case "p":
					System.out.println("p: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('p', val);
					break;
				case "q":
					System.out.println("q: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('q', val);
					break;
				case "r":
					System.out.println("r: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('r', val);
					break;
				case "s":
					System.out.println("s: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('s', val);
					break;
				case "t":
					System.out.println("t: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('t', val);
					break;
				case "u":
					System.out.println("u: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('u', val);
					break;
				case "v":
					System.out.println("v: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('v', val);
					break;
				case "w":
					System.out.println("w: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('w', val);
					break;
				case "x":
					System.out.println("x: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('x', val);
					break;
				case "y":
					System.out.println("y: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('y', val);
					break;
				case "z":
					System.out.println("z: ");
					val = Integer.parseInt(in.readLine());
					varTable.put('z', val);
					break;
				default:
					break;
				}
			}			
		}
		scanner.close();
		return varTable;
	}
	
	// Finds variables in expression without adding to Hash Map (for file input)
	private static ArrayList<String> findVarsNoInput(String st) throws NumberFormatException, IOException{
		ArrayList<String> list = new ArrayList<String>();
		String var = "";
		Scanner scanner = new Scanner(st);
		while(scanner.hasNext()){
			var = scanner.next();
			if(!list.contains(var)){
				switch(var){
				case "a":
					list.add(var);
					break;
				case "b":
					list.add(var);
					break;
				case "c":
					list.add(var);
					break;
				case "d":
					list.add(var);
					break;
				case "e":
					list.add(var);
					break;
				case "f":
					list.add(var);
					break;
				case "g":
					list.add(var);
					break;
				case "h":
					list.add(var);
					break;
				case "i":
					list.add(var);
					break;
				case "j":
					list.add(var);
					break;
				case "k":
					list.add(var);
					break;
				case "l":
					list.add(var);
					break;
				case "m":
					list.add(var);
					break;
				case "n":
					list.add(var);
					break;
				case "o":
					list.add(var);
					break;
				case "p":
					list.add(var);
					break;
				case "q":
					list.add(var);
					break;
				case "r":
					list.add(var);
					break;
				case "s":
					list.add(var);
					break;
				case "t":
					list.add(var);
					break;
				case "u":
					list.add(var);
					break;
				case "v":
					list.add(var);
					break;
				case "w":
					list.add(var);
					break;
				case "x":
					list.add(var);
					break;
				case "y":
					list.add(var);
					break;
				case "z":
					list.add(var);
					break;
				default:
					break;
				}
			}			
		}
		scanner.close();
		return list;
	}
}
